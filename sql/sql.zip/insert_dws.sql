--中间层，统计近30天的ip、cookie、浏览器、操作系统
insert overwrite table qfbap_dws.dws_user_visit_month1 partition (dt="20190713")
select ds.user_id,
ds.type,
ds.cnt,
ds.content,
row_number() over(partition by ds.user_id,ds.type order by ds.cnt) as rn,
current_date() dw_date
from
(select user_id,
'visit_ip' as type,
sum(pv) as cnt,
visit_ip as content
from qfbap_dwd.dwd_user_pc_pv 
where datediff(current_date(),in_time)<30 or datediff(current_date(),out_time)<30
group by user_id,visit_ip
union all
select user_id,
'cookie_id' as type,
sum(pv) as cnt,
cookie_id as content
from qfbap_dwd.dwd_user_pc_pv 
where datediff(current_date(),in_time)<30 or datediff(current_date(),out_time)<30
group by user_id,cookie_id
union all
select user_id,
'visit_os' as type,
sum(pv) as cnt,
visit_os as content
from qfbap_dwd.dwd_user_pc_pv 
where datediff(current_date(),in_time)<30 or datediff(current_date(),out_time)<30
group by user_id,visit_os
union all
select user_id,
'browser_name' as type,
sum(pv) as cnt,
browser_name as content
from qfbap_dwd.dwd_user_pc_pv 
where datediff(current_date(),in_time)<30 or datediff(current_date(),out_time)<30
group by user_id,browser_name) ds;




